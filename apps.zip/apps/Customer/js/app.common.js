var app = {
	serviceManagerHost: ''		// set to execute API calls on other server
};